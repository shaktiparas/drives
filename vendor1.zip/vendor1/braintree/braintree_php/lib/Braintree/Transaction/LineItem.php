<?php
namespace Braintree\Transaction;

\class_exists('Braintree\TransactionLineItem');
