<?php
namespace Test\Braintree;

class CreditCardDefaults
{
    const ISSUING_BANK = "NETWORK ONLY";
    const COUNTRY_OF_ISSUANCE = "USA";
}
